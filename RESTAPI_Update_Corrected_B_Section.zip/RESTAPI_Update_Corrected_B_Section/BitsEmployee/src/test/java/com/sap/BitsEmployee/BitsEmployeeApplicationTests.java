package com.sap.BitsEmployee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BitsEmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
