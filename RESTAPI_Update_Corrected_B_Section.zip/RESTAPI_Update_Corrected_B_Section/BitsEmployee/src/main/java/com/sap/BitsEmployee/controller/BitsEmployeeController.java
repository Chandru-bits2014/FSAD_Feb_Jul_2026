package com.sap.BitsEmployee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sap.BitsEmployee.model.BitsEmployee;
import com.sap.BitsEmployee.service.EmployeeService;

@RestController
@RequestMapping("/employees")
public class BitsEmployeeController {

	@Autowired
	EmployeeService empService;
	
	@GetMapping("/getAll")
	public List <BitsEmployee> getAllEmployees()
	{
		return empService.getAllEmployees();
	}
	//employees/getById/2
	@GetMapping("/getById/{empId}")
	public BitsEmployee getEmployeeById(@PathVariable int empId)
	{
		return empService.getEmployeeById(empId);
	}
	
	@PostMapping("/saveEmployee")
	public BitsEmployee saveEmployee(@RequestBody BitsEmployee bitsEmployee)
	{
		return empService.saveEmployee(bitsEmployee);
	}
	
	@DeleteMapping("/deleteById/{empId}")
	public String deleteEmployeeById(@PathVariable int empId)
	{
		empService.deleteEmployeeById(empId);
		return "Deleted Employee Record successfully...";
	}
	@PutMapping("/updateById/{empId}")
	public BitsEmployee updateEmployee(@PathVariable int empId,@RequestBody BitsEmployee bitsEmployee)
	{
		return empService.updateEmployee(empId, bitsEmployee);
	}
	
}
