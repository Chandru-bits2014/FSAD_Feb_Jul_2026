package com.sap.BitsEmployee.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sap.BitsEmployee.model.BitsEmployee;

@Service
public interface EmployeeService {

	
	public List <BitsEmployee> getAllEmployees();
	public BitsEmployee getEmployeeById(int id);
	public BitsEmployee saveEmployee(BitsEmployee bitsEmployee);
	public void deleteEmployeeById(int id);
	public BitsEmployee updateEmployee(int id,BitsEmployee bitsEmployee);
}
