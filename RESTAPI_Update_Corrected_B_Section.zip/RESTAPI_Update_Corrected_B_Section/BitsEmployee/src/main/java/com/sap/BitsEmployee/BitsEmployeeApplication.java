package com.sap.BitsEmployee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BitsEmployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(BitsEmployeeApplication.class, args);
		System.out.println("We are Creating SPRINGBOOT based RESTApi");
	}

}
