package com.sap.BitsEmployee.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name="bitsemployee")
public class BitsEmployee {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	int id;
	
	@Column(name="first_Name")
	String firstName;
	
	@Column(name="last_Name")
	String lastName;
	
	@Column(name="department")
	String department;
	
	@Column(name="designation")
	String designation;
	
	@Column(name="salary")
	int salary;

}
