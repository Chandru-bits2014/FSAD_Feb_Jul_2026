package com.sap.BitsEmployee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sap.BitsEmployee.dao.EmployeeRepository;
import com.sap.BitsEmployee.model.BitsEmployee;

@Service 
public class EmployeeServiceImpl implements EmployeeService{
	
	
	@Autowired
	EmployeeRepository empRepo;

	@Override
	public List<BitsEmployee> getAllEmployees() {
		// TODO Auto-generated method stub
		return empRepo.findAll();
	}

	@Override
	public BitsEmployee getEmployeeById(int id) {
		// TODO Auto-generated method stub
		return empRepo.findById(id).get();
	}

	@Override
	public BitsEmployee saveEmployee(BitsEmployee bitsEmployee) {
		// TODO Auto-generated method stub
		return empRepo.save(bitsEmployee);
	}

	@Override
	public void deleteEmployeeById(int id) {
		// TODO Auto-generated method stub
		empRepo.deleteById(id);
	}

	@Override
	public BitsEmployee updateEmployee(int id, BitsEmployee bitsEmployee) {
		// TODO Auto-generated method stub
		BitsEmployee bitsEmployeeU = empRepo.findById(id).get();
		
		bitsEmployeeU.setFirstName(bitsEmployee.getFirstName());
		bitsEmployeeU.setLastName(bitsEmployee.getLastName());
		bitsEmployeeU.setDepartment(bitsEmployee.getDepartment());
		bitsEmployeeU.setDesignation(bitsEmployee.getDesignation());
		bitsEmployeeU.setSalary(bitsEmployee.getSalary());
		empRepo.save(bitsEmployeeU);
		return bitsEmployeeU;
	}

}
