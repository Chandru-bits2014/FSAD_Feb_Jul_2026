package com.sap.BitsEmployee.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sap.BitsEmployee.model.BitsEmployee;


public interface EmployeeRepository extends JpaRepository <BitsEmployee,Integer> {

}
