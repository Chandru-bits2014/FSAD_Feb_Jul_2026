import React from 'react'

export default function Update() {
  return (
    <div>
      <h3>Updating Records!!!</h3>
    </div>
  )
}


