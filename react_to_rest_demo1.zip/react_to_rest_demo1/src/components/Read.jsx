import React from 'react'
import {useParams} from 'react-router-dom'
import { useEffect, useState } from 'react'
import {Link,useNavigate} from 'react-router-dom'
import axios from 'axios'

export default function Read() {
    const [students,setStudents] = useState([])
    const {rollNo} = useParams();
    useEffect(()=>{
        axios.get('http://localhost:8080/students/allStudents/'+rollNo)
        .then(res =>setStudents(res.data))
        .catch(err=>console.log(err))
    },[])//Correction []


  return (


    <div>
      <h3>Student Record for Student with Id {students.rollNo}</h3>
      <div>
        <strong>First Name :{students.firstName}</strong>
      </div>
           <div>
        <strong>Last Name :{students.lastName}</strong>
      </div>
      <div>
        <strong>Marks :{students.marks}</strong>
      </div>
      <Link to={'/'}>Go Back To Home Page</Link>
    </div>
  )
}


