import React, { useEffect, useState } from 'react'
import {Link,useNavigate} from 'react-router-dom'
import axios from 'axios'
export default function Home() {

    const [students,setStudents] = useState([])
    const navigate = useNavigate()
//UseEffect being invoked when the Component is Loaded
    useEffect(()=>{
        axios.get('http://localhost:8080/students/allStudents')
       .then (res => setStudents(res.data))
       .catch(err => console.log(err))

    },[])
    
const handleDelete =(rollNo)=>{
    console.log('Delete');
    axios.delete('http://localhost:8080/students/allStudents/'+rollNo)
    .then(res =>{
       // navigate('/')
        location.reload();
    }).catch(err=>console.log(err));
}


  return (
    <div>
        <h1>List Of Students</h1>
        <div>
            <Link to='/create'>Add Student</Link>
            <table align="center" border="2">
                <thead>
                    <tr>
                    <th>RollNO</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Marks</th>
                    <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        students.map((student,i) =>(
                            <tr key={i}>
                                <td>{student.rollNo}</td>
                                <td>{student.firstName}</td>
                                <td>{student.lastName}</td>
                                <td>{student.marks}</td>
                                <td>
                                    <Link to={`/read/${student.rollNo}`}>Read</Link>|
                                    <Link to={`/update/${student.rollNo}`}>Update</Link>
                                    <button onClick={e => handleDelete(student.rollNo)}>Delete</button>
                                </td>
                            </tr>
                        ))
                    }

                </tbody>
            </table>
        </div>
      
    </div>
  )
}

 
