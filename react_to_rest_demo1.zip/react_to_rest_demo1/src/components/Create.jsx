import React from 'react'
import { useEffect, useState } from 'react'
import {Link,useNavigate} from 'react-router-dom'
import axios from 'axios'

export default  function Create() {
    const [studData,setStudData] = useState({
        firstName:'',
        lastName:'',
        marks:''
    })
    const navigate = useNavigate()
    const handleSubmit=(event)=>{
            event.preventDefault();
            axios.post('http://localhost:8080/students/allStudents',studData)
            .then(res =>{
                console.log(res.data);
                navigate('/');
           })
           .catch(err=>console.log(err))
    }
  return (
    <div>
      <h2>Insert Student Details!!!</h2>
      <form onSubmit={handleSubmit}>
      <div>
        <label>Enter First Name </label>
        <input type="text" onChange={e=>setStudData({...studData,firstName:e.target.value})} />
      </div>
       <div>
        <label>Enter Last Name </label>
        <input type="text" onChange={e=>setStudData({...studData,lastName:e.target.value})} />
      </div>
       <div>
        <label>Enter Marks </label>
        <input type="text" onChange={e=>setStudData({...studData,marks:e.target.value})} />
      </div>
      <button>Submit StudentData</button>
      <Link to='/'>Back To Home</Link>
      </form>
    </div>
  )
}

