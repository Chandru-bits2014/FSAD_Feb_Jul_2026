import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from './assets/vite.svg'
import heroImg from './assets/hero.png'
import './App.css'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Home from './components/Home'
import Update from './components/Update'
import Create from './components/Create'
import Read from './components/Read'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <h3>Welcome to React Connectivity to REST Api!!!</h3>
      <h3>Welcome to Students Data Management Page</h3>
     <BrowserRouter>
      <Routes>
          <Route path="/" element={<Home />}></Route>
          <Route path="/create" element={<Create />}></Route>
          <Route path="/update/:rollNo" element={<Update />}></Route>
          <Route path="/read/:rollNo" element={<Read />}></Route>
      </Routes>
     </BrowserRouter>
    </>
  )
}

export default App
