//import fetch from "node-fetch";
/*const chai = require('chai'),
assert = chai.assert,
expect = chai.expect,
should = chai.should()*/
//import {chai} from chai;
import { assert,expect } from 'chai';
import {should} from 'chai';



describe('String',function(){
    let name='John'
/*
    it('should be of type string',function(){
        name.should.be.a('string')
        expect(name).to.be.a('string')
        assert.typeOf(name,'string')
    })

    it('should contain John',function(){
        name.should.not.equal('Kate')
        name.should.equal('John')
        expect(name).to.equal('John')
        assert.equal(name,'John')
    })
   */
   it('should be of type string',function(){
        name?.should?.be?.a('string')
        expect(name)?.to?.be?.a('string')
        assert?.typeOf(name,'string')
    })

    it('should contain John',function(){
        name?.should?.not?.equal('Kate')
        name?.should?.equal('John')
        expect(name)?.to?.equal('John')
        assert?.equal(name,'John')
    })

    it('app should return hello',function(){
            const app =()=>{
                return "hello";
            }
            assert.equal(app(),'hello');
        });
      it('app1 should return sum',function(){
            const app1 =(n1,n2)=>{
                return n1 + n2 ;
            }
            assert.equal(app1(100,200),300);
        });
         it('app1 should return product',function(){
            const app2 =(n1,n2)=>{
                return n1 * n2 ;
            }
            assert.equal(app2(10,20),200);
        });
  it('app2 should return difference',function(){
            const app2 =(n1,n2)=>{
                return n1 - n2 ;
            }
            assert.equal(app2(100,20),80);
        }); /* */   /* */     /* */
    it('app2 should return dividend',function(){
            const app2 =(n1,n2)=>{
                return n1 / n2 ;
            }
            assert.equal(app2(100,20),5);
        });  /**/
  /*   it.skip('app2 should return dividend',function(){
            const app2 =(n1,n2)=>{
                return n1 / n2 ;
            }
            assert.equal(app2(100,20),5);
        });  */
        
           /*       it.only('app should return difference',function(){
            const app2 =(n1,n2)=>{
                return n1 - n2 ;
            }
            assert.equal(app2(100,20),80);
        });*/ /*  */

        /* HOOKS*/
        before(function(){
                console.log("This is Invoked Before All Tests Once");
        });
        this.beforeEach(function(){
                console.log("This is Invoked Before Each Test ... ");
        });
        after(function(){
                console.log("This is Invoked After All Tests Once");
        });
        this.afterEach(function(){
                console.log("This is Invoked After Each Tests ....");
        });/**/
       /* */
        
       
})

