/*const assert = require('chai').assert;
const app = require('../app');*/
import app from '../app.js';
import { assert } from 'chai'; /**/
describe('app',function(){
   it('app should return hello',function(){
        assert.equal(app(),'hello');
    });

});