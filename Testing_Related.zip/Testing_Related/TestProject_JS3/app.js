/*module.exports=function app(){
    return "hello";
}*/
/*export default*/ function app  (){
       return "hello";
}/* */
//export default app
export default app