package com.oauth.oauth_security_proj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OauthSecurityProjApplication {

	public static void main(String[] args) {
		SpringApplication.run(OauthSecurityProjApplication.class, args);
	}

}
