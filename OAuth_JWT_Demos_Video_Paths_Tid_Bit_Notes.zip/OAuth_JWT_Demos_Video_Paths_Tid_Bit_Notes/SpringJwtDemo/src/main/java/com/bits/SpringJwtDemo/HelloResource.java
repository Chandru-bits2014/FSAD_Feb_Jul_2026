package com.bits.SpringJwtDemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bits.SpringJwtDemo.model.AuthenticationRequest;
import com.bits.SpringJwtDemo.model.AuthenticationResponse;

@Controller
@RequestMapping("/greet")
public class HelloResource {
	@Autowired
	AuthenticationManager authenticationManager;
	
	@Autowired
	MyUserDetailsService userDetailsService;
	
	@Autowired
	private JwtUtil jwtTokenUtil;
	/*
	@RequestMapping(value="/hello",method=RequestMethod.GET)
	public String sayHello()
	{
		return "Hey!! Good Day Welcome to Spring Security - JWT";
	}
	@RequestMapping(value="/welcome",method=RequestMethod.GET)
	public String sayHi()
	{
		return "Hey!! Good Day Welcome to Spring Security - JWT";
	}*/
	
	@RequestMapping(value="/authenticate",method=RequestMethod.POST)
	public ResponseEntity <?> createAuthenticationToken(@RequestBody AuthenticationRequest authenticationRequest) throws Exception
	{
		try
		{
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authenticationRequest.getUsername(),authenticationRequest.getPassword()));
		}
		catch(BadCredentialsException bce)
		{
			throw new Exception("Invalid UserName or Password") ;
		}
		final UserDetails userDetails = userDetailsService.loadUserByUsername(authenticationRequest.getUsername());
		final String jwt = jwtTokenUtil.generateToken(userDetails);
		System.out.println("Token is "+jwt);
		return ResponseEntity.ok(new AuthenticationResponse(jwt));
	}

}
