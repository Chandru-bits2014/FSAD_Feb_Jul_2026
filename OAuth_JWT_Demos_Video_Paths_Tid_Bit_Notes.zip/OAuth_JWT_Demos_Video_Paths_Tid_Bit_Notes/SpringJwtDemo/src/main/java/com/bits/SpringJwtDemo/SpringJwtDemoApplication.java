package com.bits.SpringJwtDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
//@ComponentScan(basePackages= {"com.bits.SpringJwtDemo.*","com.bits.SpringJwtDemo","com.bits.SpringJwtDemo.filters","com.bits.SpringJwtDemo.model"})
public class SpringJwtDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJwtDemoApplication.class, args);
		System.out.println("Welcome to Spring Security through  - JWT ...");
	}

}
